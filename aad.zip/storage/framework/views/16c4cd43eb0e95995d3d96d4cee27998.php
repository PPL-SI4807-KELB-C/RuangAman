<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'info',
    'title' => null,
    'dismissible' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'info',
    'title' => null,
    'dismissible' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$variants = [
    'info' => 'bg-blue-50 border-blue-400 text-blue-800',
    'success' => 'bg-green-50 border-green-400 text-green-800',
    'warning' => 'bg-amber-50 border-amber-400 text-amber-800',
    'danger' => 'bg-red-50 border-safety-rose text-red-800',
    'brand' => 'bg-brand-50 border-brand-400 text-brand-800',
];

$classes = 'rounded-lg border-l-4 p-4 ' . ($variants[$variant] ?? $variants['info']);
?>

<div <?php echo e($attributes->merge(['class' => $classes, 'role' => 'alert'])); ?>>
    <div class="flex">
        <div class="flex-1">
            <?php if($title): ?>
                <h3 class="text-sm font-semibold"><?php echo e($title); ?></h3>
            <?php endif; ?>
            <div class="text-sm <?php echo e($title ? 'mt-1' : ''); ?>">
                <?php echo e($slot); ?>

            </div>
        </div>
        <?php if($dismissible): ?>
            <button type="button" class="ml-4 text-sm font-medium opacity-70 hover:opacity-100" aria-label="Tutup">
                ×
            </button>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xamppp\htdocs\Tubes IAE\RuangAman\resources\views/components/alert.blade.php ENDPATH**/ ?>