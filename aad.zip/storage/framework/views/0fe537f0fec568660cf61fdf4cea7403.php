<!-- Tombol Keluar Cepat (FR-28). Layout wajib memuat <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">. -->
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'logoutUrl' => '/logout',
    'redirectTo' => 'https://www.google.com',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'logoutUrl' => '/logout',
    'redirectTo' => 'https://www.google.com',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div
    x-data="{
        armed: false,
        armTimer: null,
        handleEscape() {
            if (this.armed) {
                this.quickExit();
                return;
            }
            this.armed = true;
            clearTimeout(this.armTimer);
            this.armTimer = setTimeout(() => { this.armed = false; }, 1200);
        },
        quickExit() {
            sessionStorage.clear();
            const leave = () => window.location.replace('<?php echo e($redirectTo); ?>');
            const token = document.querySelector('meta[name=csrf-token]')?.content;
            if (!token) {
                return leave();
            }
            fetch('<?php echo e($logoutUrl); ?>', {
                method: 'POST',
                headers: { 'X-CSRF-TOKEN': token, 'Accept': 'application/json' },
                keepalive: true,
            }).catch(() => {}).finally(leave);
        }
    }"
    @keydown.escape.window="handleEscape()"
    class="fixed bottom-4 right-4 z-50">
    <button
        @click="quickExit()"
        type="button"
        class="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 px-4 rounded-full shadow-lg transition duration-200 focus:outline-none focus:ring-4 focus:ring-red-300"
        title="Keluar cepat: klik tombol atau tekan Esc dua kali untuk mengakhiri sesi dan pindah ke situs netral">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd" />
        </svg>
        <span>Keluar Cepat (ESC ×2)</span>
    </button>
</div>
<?php /**PATH C:\xamppp\htdocs\Tubes IAE\RuangAman\resources\views/components/quick-exit.blade.php ENDPATH**/ ?>