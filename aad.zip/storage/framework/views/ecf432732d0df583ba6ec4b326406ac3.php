<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'slate']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'slate']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$variants = [
    'brand' => 'bg-brand-100 text-brand-800 ring-brand-500/20',
    'success' => 'bg-green-100 text-green-800 ring-green-500/20',
    'warning' => 'bg-amber-100 text-amber-800 ring-amber-500/20',
    'danger' => 'bg-red-100 text-red-800 ring-red-500/20',
    'info' => 'bg-blue-100 text-blue-800 ring-blue-500/20',
    'slate' => 'bg-slate-100 text-slate-700 ring-slate-500/20',
    'rose' => 'bg-safety-rose/10 text-safety-rose ring-safety-rose/20',
];

$classes = 'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ' . ($variants[$variant] ?? $variants['slate']);
?>

<span <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</span>
<?php /**PATH C:\xamppp\htdocs\Tubes IAE\RuangAman\resources\views/components/badge.blade.php ENDPATH**/ ?>