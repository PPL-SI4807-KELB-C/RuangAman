<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'id' => null,
    'label' => null,
    'options' => [],
    'value' => null,
    'placeholder' => null,
    'helper' => null,
    'error' => null,
    'required' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'id' => null,
    'label' => null,
    'options' => [],
    'value' => null,
    'placeholder' => null,
    'helper' => null,
    'error' => null,
    'required' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$id ??= $name;
$hasError = $error !== null && $error !== '';
?>

<div <?php echo e($attributes->only('class')); ?>>
    <?php if($label): ?>
        <label for="<?php echo e($id); ?>" class="block text-sm font-medium text-slate-700 mb-1">
            <?php echo e($label); ?>

            <?php if($required): ?>
                <span class="text-safety-rose" aria-hidden="true">*</span>
            <?php endif; ?>
        </label>
    <?php endif; ?>

    <select
        name="<?php echo e($name); ?>"
        id="<?php echo e($id); ?>"
        <?php if($required): ?> required <?php endif; ?>
        aria-invalid="<?php echo e($hasError ? 'true' : 'false'); ?>"
        <?php if($hasError): ?> aria-describedby="<?php echo e($id); ?>-error" <?php endif; ?>
        <?php echo e($attributes->except('class')->merge(['class' => 'block w-full rounded-lg border shadow-sm text-sm transition bg-white px-3 py-2.5 ' . ($hasError ? 'border-safety-rose focus:ring-safety-rose focus:border-safety-rose' : 'border-slate-300 focus:ring-brand-500 focus:border-brand-500')])); ?>

    >
        <?php if($placeholder): ?>
            <option value="" disabled <?php if(old($name, $value) === '' || old($name, $value) === null): echo 'selected'; endif; ?>><?php echo e($placeholder); ?></option>
        <?php endif; ?>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionValue => $optionLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($optionValue); ?>" <?php if(old($name, $value) == $optionValue): echo 'selected'; endif; ?>><?php echo e($optionLabel); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php if($helper && ! $hasError): ?>
        <p class="mt-1 text-xs text-slate-500"><?php echo e($helper); ?></p>
    <?php endif; ?>

    <?php if($hasError): ?>
        <p id="<?php echo e($id); ?>-error" class="mt-1 text-xs text-safety-rose"><?php echo e($error); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH C:\xamppp\htdocs\Tubes IAE\RuangAman\resources\views/components/select.blade.php ENDPATH**/ ?>