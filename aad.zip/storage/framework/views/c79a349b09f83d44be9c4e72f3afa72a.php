

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Pendaftaran Kegiatan Saya</h1>
            <p class="mt-1 text-sm text-slate-500">Pantau status pendaftaran webinar atau lokakarya edukasi yang Anda ikuti.</p>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => ''.e(route('kegiatan.index')).'','variant' => 'primary','size' => 'md']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('kegiatan.index')).'','variant' => 'primary','size' => 'md']); ?>
                Jelajahi Kegiatan Edukasi
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
        </div>
    </div>

    <?php if($pendaftaranList->isEmpty()): ?>
        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'py-12 text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'py-12 text-center']); ?>
            <p class="text-sm text-slate-500">Anda belum mendaftar pada kegiatan edukasi apa pun.</p>
            <div class="mt-4">
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => ''.e(route('kegiatan.index')).'','variant' => 'secondary','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('kegiatan.index')).'','variant' => 'secondary','size' => 'sm']); ?>
                    Lihat Daftar Kegiatan Tersedia
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    <?php else: ?>
        <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-600">
                    <thead class="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
                        <tr>
                            <th scope="col" class="px-6 py-3.5">Kegiatan Edukasi</th>
                            <th scope="col" class="px-6 py-3.5">Jadwal &amp; Metode</th>
                            <th scope="col" class="px-6 py-3.5 text-center">Sisa Kuota</th>
                            <th scope="col" class="px-6 py-3.5 text-center">Status Pendaftaran</th>
                            <th scope="col" class="px-6 py-3.5 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__currentLoopData = $pendaftaranList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $kegiatan = $pendaftaran->kegiatanEdukasi;
                            ?>
                            <tr class="hover:bg-slate-50/75 transition">
                                <td class="px-6 py-4">
                                    <a href="<?php echo e(route('kegiatan.show', $kegiatan)); ?>" class="font-semibold text-slate-900 hover:text-brand-700">
                                        <?php echo e($kegiatan->judul); ?>

                                    </a>
                                    <div class="mt-0.5 text-xs text-slate-500">
                                        Narasumber: <?php echo e($kegiatan->narasumber ?: '-'); ?>

                                    </div>
                                    <?php if(in_array($pendaftaran->status_pendaftaran, [\App\Models\PendaftaranKegiatan::STATUS_AKTIF, \App\Models\PendaftaranKegiatan::STATUS_HADIR], true) && $kegiatan->lokasi_atau_tautan): ?>
                                        <div class="mt-1 text-xs text-brand-700 break-all">
                                            <?php echo e($kegiatan->metode === 'online' ? 'Tautan: ' : 'Lokasi: '); ?><?php echo e($kegiatan->lokasi_atau_tautan); ?>

                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-xs">
                                    <div class="font-medium text-slate-800"><?php echo e($kegiatan->tanggal_mulai->translatedFormat('d M Y')); ?></div>
                                    <div class="text-slate-500"><?php echo e(substr((string) $kegiatan->waktu_mulai, 0, 5)); ?> WIB &bull; <?php echo e($kegiatan->metodeLabel()); ?></div>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-center text-xs">
                                    <span class="font-semibold text-slate-800"><?php echo e($kegiatan->sisaKuota()); ?></span> / <?php echo e($kegiatan->kuota); ?> kursi
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-center">
                                    <?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['variant' => $pendaftaran->statusBadgeVariant()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendaftaran->statusBadgeVariant())]); ?>
                                        <?php echo e($pendaftaran->statusLabel()); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
                                </td>
                                <td class="whitespace-nowrap px-6 py-4 text-right">
                                    <div class="inline-flex items-center gap-2">
                                        <a
                                            href="<?php echo e(route('kegiatan.show', $kegiatan)); ?>"
                                            class="inline-flex items-center rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 shadow-sm hover:bg-slate-50"
                                        >
                                            Detail
                                        </a>

                                        <?php if($pendaftaran->bisaDibatalkan()): ?>
                                            <button
                                                type="button"
                                                @click="$dispatch('open-confirm-modal', <?php echo e(Js::from([
                                                    'title' => 'Batalkan Pendaftaran',
                                                    'message' => 'Apakah Anda yakin ingin membatalkan pendaftaran untuk kegiatan \"' . $kegiatan->judul . '\"?',
                                                    'action' => route('pendaftaran-kegiatan.cancel', $pendaftaran),
                                                    'method' => 'PATCH',
                                                    'confirmText' => 'Ya, Batalkan',
                                                    'confirmVariant' => 'danger',
                                                ])); ?>)"
                                                class="inline-flex items-center rounded-lg border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-medium text-safety-rose hover:bg-red-100"
                                            >
                                                Batalkan Pendaftaran
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if($pendaftaranList->hasPages()): ?>
                <div class="border-t border-slate-200 bg-slate-50/50 px-6 py-4">
                    <?php echo e($pendaftaranList->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamppp\htdocs\Tubes IAE\RuangAman\resources\views/pendaftaran-kegiatan/index.blade.php ENDPATH**/ ?>