<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['header' => null, 'footer' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['header' => null, 'footer' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden'])); ?>>
    <?php if($header): ?>
        <div class="px-5 py-4 border-b border-slate-100 bg-slate-50/50">
            <?php echo e($header); ?>

        </div>
    <?php endif; ?>

    <div class="px-5 py-5">
        <?php echo e($slot); ?>

    </div>

    <?php if($footer): ?>
        <div class="px-5 py-4 border-t border-slate-100 bg-slate-50/50">
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xamppp\htdocs\Tubes IAE\RuangAman\resources\views/components/card.blade.php ENDPATH**/ ?>